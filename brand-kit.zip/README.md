# SPORB Protocol — Brand Kit

## Brand Identity

- **Name:** SPORB Protocol
- **Token:** $SPORB
- **Tagline:** Orbital Data Infrastructure
- **Website:** https://sporb.xyz

## Colors

| Name | Hex | Usage |
|------|-----|-------|
| Background | `#0a0a0f` | Page background |
| Foreground | `#e8e8ed` | Text color |
| Accent | `#00d4aa` | Primary accent, buttons, links |
| Accent Dim | `rgba(0, 212, 170, 0.15)` | Subtle accent backgrounds |
| Secondary | `#7c3aed` | Purple accent, highlights |
| Muted | `#6b6b80` | Secondary text |
| Border | `rgba(255,255,255,0.06)` | Subtle borders |

## Fonts

- **Primary:** Space Grotesk (300, 400, 500, 600, 700)
  - Google Fonts: https://fonts.google.com/specimen/Space+Grotesk
- **Monospace:** JetBrains Mono (400, 700)
  - Google Fonts: https://fonts.google.com/specimen/JetBrains+Mono

## Logo Files

- `logo.svg` — Vector format (preferred)
- `logo.png` — 400x400px PNG

## Social Links

- X / Twitter: https://x.com/sporb_xyz
- Telegram: https://t.me/sporb_xyz
- GitHub: https://github.com/sporbxyz
- Discord: https://discord.gg/sporb_xyz
